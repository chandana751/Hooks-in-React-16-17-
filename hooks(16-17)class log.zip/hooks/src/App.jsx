import React from 'react';
import Useeffect from './Useeffect';
import Counter from './Counter';
import Timer from './assets/Timer';
import UsersList from './UsersList';
import { Greeting, Temperature } from './Greeting'; 
import External from './External.jsx';
import Button from './Button.jsx';
import ProductCard from './ProductCard.jsx';
import Index from './Index.jsx';
import Home from './Home.jsx';
import About from './About.jsx';
import Contact from './Contact.jsx';
import { BrowserRouter,Routes,Route } from 'react-router-dom';

function App() {
  return (
    <div>
      <h1>Welcome to React</h1>
      <Useeffect />
      <h2>React counter function</h2>
      <Counter />
      <h2>Timer changes</h2>
      <Timer />
      <UsersList />
      <Greeting />
      <Temperature />
      <External />
      <Button />
      <ProductCard />
      <h1>This is App File</h1>
      <BrowserRouter>
      <Routes>
        <Route path='/Error' element={<h1>404 Page Not</h1>} />
        <Route path='/' element={<Index />} />
        <Route path='/About' element={<About />} />
        <Route path='/Contact' element={<Contact />} />
        <Route path='/Home' element={<Home />} />

      </Routes>
      </BrowserRouter>
      
      
    </div>
  );
}

export default App;
