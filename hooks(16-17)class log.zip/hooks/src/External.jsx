import React from 'react';
import "./ExternalCSS.css";


function External() {
  return (
    <div className="container">
      <h1 className="title">React External CSS</h1>
      <img src="download.jpeg" alt="moon.jpeg" height="10%" />
    </div>
  );
}

export default External;
