import styled from "styled-components";
import React from 'react';

const Card = styled.div`
    background-color: green;
    border-radius:10px;
    padding: 20px;
    text-align:center;
    box-shadow:0 2px 5px rgba(0,0,0,0.1);
    `;

const Title =styled.h3`
    color:#333;
    `;

function ProductCard(){
    return (
        <Card>
            <Title>Product Name</Title>
            <h1>Chandana B R</h1>
            <img src="download.jpeg" alt="moon.jpeg" height="10%" />
            <p>$25.99</p>
        </Card>
    )
}
export default ProductCard;