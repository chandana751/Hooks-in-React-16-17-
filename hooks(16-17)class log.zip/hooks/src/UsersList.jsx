import React,{ useEffect,useState} from 'react';

function UsersList() {
    const [users,setUsers]= useState([]);
    const [loading, setLoading]= useState(true);
    useEffect(() => {
        async function fetchData() {
            const res= awatfetch("http://jsonplaceholder.typicode.com/users");
            const data= await res.json();
            setUsers(data);
            setLoading(true);
        }
        fetchData();
    }, []); //fetch once

  return (
    <div>
      <h2>Users List</h2>
      {loading ? (
        <p>Loading....</p>
      ) : (
        <ul>
            {users.map((user) => (
                <>
                <li key={user.id}>{user.name}{user.category}</li>
                
                <p key={user.id}>{user.category}</p>
                </>
            ))}
        </ul>
      )}
    </div>
  );
}

export default UsersList;
