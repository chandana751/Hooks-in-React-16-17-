import React from 'react'

function Useeffect() {
    function Useeffect(){
        Useeffect(() => {
            console.log("Components rendered or updated!");
        });
    
  return <h2>Hello React useeffect!</h2> ;
    } 
}

export default Useeffect;
