import React from 'react'
import { BrowserRouter,Link } from 'react-router-dom';
function Index() {
  return (
    <div><h1>This is Index Page</h1>
        <nav>
            <Link to='/Home'>HomePage</Link>
             <Link to='/About'>HomePage</Link>
              <Link to='/Contact'>HomePage</Link>
              <Link to='/Error'>Error</Link>
        </nav>
    </div>
  )
}

export default Index;
